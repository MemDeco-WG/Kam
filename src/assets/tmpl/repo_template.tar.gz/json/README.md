# module.json
- kam 兼容mmrl
module.json是兼容mmrl,保留的
真正的索引文件在：
index/...
