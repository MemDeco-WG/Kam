#!/system/bin/sh
# Template customize script
# This script runs during module installation

# Example: set permissions
# set_perm_recursive $MODDIR 0 0 0755 0644

# Add your customization here

ui_print "Template module {{id}} installed"
