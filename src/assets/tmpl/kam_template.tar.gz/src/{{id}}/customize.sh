#! bin/sh

# Hello {{id}}

# This is a customize script for the kam module
# You can add custom installation or configuration commands here

# "Installing {{name}} module..."

# echo "Module installed successfully"
