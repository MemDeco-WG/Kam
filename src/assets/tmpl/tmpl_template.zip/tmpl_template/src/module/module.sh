#!/system/bin/sh
# This is a sample module script for {{name}}
# Version: {{version}}
# Author: {{author}}

MODDIR=${0%/*}

# Your module code here
# This template can be used recursively to create other templates

echo "Module {{name}} loaded"
