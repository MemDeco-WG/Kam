# Changelog

All notable changes to this project will be documented in this file.

- Initial {{name}}-{{id}}-{{version}}
author : {{author}}
versionCode : {{versionCode}}
description : {{description}}
