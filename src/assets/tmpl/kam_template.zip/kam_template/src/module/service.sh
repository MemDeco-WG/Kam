#!/system/bin/sh
# Kam module: {{name}}
# Version: {{version}}
# Author: {{author}}

MODDIR=${0%/*}

# Service script for kam module

# Your service code here

echo "Kam module {{name}} service started"
