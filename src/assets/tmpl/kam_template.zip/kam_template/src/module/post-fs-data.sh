#!/system/bin/sh
# Post-fs-data script for {{name}}

# Your post-fs-data code here

echo "Post-fs-data for {{name}} executed"
