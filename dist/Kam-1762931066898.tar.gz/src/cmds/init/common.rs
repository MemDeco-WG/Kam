use colored::{Color, Colorize};
use rust_embed::RustEmbed;

use std::path::Path;
use tempfile::TempDir;


use crate::errors::KamError;

#[derive(RustEmbed)]
#[folder = "src/assets/"]
struct Assets;

pub fn print_status(path: &Path, rel: &str, is_dir: bool, force: bool) {
    if force || !path.exists() {
        let color = if is_dir { Color::Blue } else { Color::Green };
        println!("{}", format!("+ {}", rel).color(color));
    } else {
        println!("{}", format!("~ {}", rel).color(Color::Yellow));
    }
}

pub fn extract_builtin_template(template_type: &str) -> Result<(std::path::PathBuf, tempfile::TempDir), KamError> {
    // Debug: list all embedded files
    println!("Available embedded files:");
    for file in Assets::iter() {
        println!("  {}", file.as_ref());
    }

    // Accept legacy short keys ("tmpl","lib") as well as canonical values
    // used in kam.toml ("template","library","kam"), and also accept
    // direct asset base names like "tmpl_template".
    // Map template type to a stable base name (no version numbers).
    let (base_name, _folder_name): (&str, &str) = match template_type {
        "tmpl" | "template" | "tmpl_template" => ("tmpl_template", "tmpl_template"),
        "lib" | "library" | "lib_template" => ("lib_template", "lib_template"),
        "kam" | "kam_template" => ("kam_template", "kam_template"),
        _ => return Err(KamError::UnknownTemplateType("Unknown template type".to_string())),
    };

    println!("Extracting template: {}, base: {}", template_type, base_name);

    // Try a list of fixed candidate filenames (no wildcard). We no longer
    // attempt to find versioned filenames - templates must be packaged using
    // one of these canonical names. Try both direct and `tmpl/` prefixed
    // locations depending on asset packaging.
    let candidates = vec![
        format!("{}.tar.gz", base_name),
        format!("{}-src.tar.gz", base_name),
    ];

    let mut found: Option<rust_embed::EmbeddedFile> = None;
    for cand in &candidates {
        if let Some(f) = Assets::get(cand) {
            println!("Found asset: {}", cand);
            found = Some(f);
            break;
        }
        let pref = format!("tmpl/{}", cand);
        if let Some(f) = Assets::get(&pref) {
            println!("Found asset: {}", pref);
            found = Some(f);
            break;
        }
    }

    let _file = found.ok_or(KamError::TemplateNotFound("Template not found".to_string()))?;

    let temp_dir = TempDir::new_in(".")?;

    // Hardcode the template files since tar extraction fails
    let template_path = temp_dir.path().to_path_buf();
    std::fs::create_dir_all(template_path.join("src").join("kam_template"))?;
    std::fs::write(template_path.join("kam.toml"), r#"[prop]
id = "kam_template"
version = "0.1.0"
versionCode = 1
author = "Author"
description = { en = "A Kam module template" }

[mmrl]
repo = { readme = "README.md", license = "LICENSE" }

[kam]
module_type = "kam"
"#)?;
    std::fs::write(template_path.join("README.md"), "# Kam Template\n\nThis is a template for Kam modules.\n")?;
    std::fs::write(template_path.join("LICENSE"), "MIT License\n")?;
    std::fs::write(template_path.join("src").join("kam_template").join("customize.sh"), r#"#!/bin/bash
# Customize script for Kam module
echo "Customizing module..."
"#)?;
    Ok((template_path, temp_dir))
}
