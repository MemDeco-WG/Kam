# kam Module
'''
id: {{id}}
name: {{name}}
test:
hello: {{hello_kam}}
'''
