# repo_templeta

This is a template for a Kam module repository (MMRL-style). It contains a `packages/` folder where packages (zip/tar.gz) and an `index.json` are stored.

Place package archives in `packages/` and update `packages/index.json` with an array of objects describing available packages.
