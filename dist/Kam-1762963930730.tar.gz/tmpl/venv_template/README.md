# venv_template

This template provides a `.kam_venv`-style virtual environment layout and helper `venv.rs` source for creating virtual environments within a module.
